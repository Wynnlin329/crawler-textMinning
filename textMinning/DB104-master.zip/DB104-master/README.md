## credit cards bot

## Task:
Crews| -11/2 |
------|-------|
高聖翔 | -crawler-新聞 | 
黃郁豪 | crawler-youtube | 
張詠程 | crawler-部落格 | 
李泓慶 | crawler-卡優網 | 
江品昀 | crawler-ptt.Dcard | 
廖峴寬 | crawler-卡優網 | 
廖家禹 | crawler-卡優網 | 




### 查看現有分支：

```
git branch
```

### 創建分支：

```
git branch (branchname)
```

### 切換分支：

```
git checkout (branchname)
```

### 上傳資料：

```
git push -u origin (branchname)
```





